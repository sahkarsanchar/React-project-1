import express from "express";
import Enquiry from "../models/Enquiry.js";

const router = express.Router();

// POST enquiry (save to DB)
router.post("/", async (req, res) => {
  try {
    const { name, contact, email, message } = req.body;

    if (!name || !contact || !email || !message) {
      return res.status(400).json({ success: false, message: "All fields are required" });
    }

    const enquiry = new Enquiry({ name, contact, email, message });
    await enquiry.save();

    res.status(201).json({ success: true, message: "Enquiry submitted successfully", data: enquiry });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error", error: error.message });
  }
});

export default router;

export const login = (req, res) => {
  const { username, password } = req.body;

  // Simple check (later connect DB)
  if (username === "admin" && password === "1234") {
    return res.json({ success: true, message: "Login successful" });
  } else {
    return res.status(401).json({ success: false, message: "Invalid credentials" });
  }
};

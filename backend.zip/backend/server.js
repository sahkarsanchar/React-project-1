import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import mongoose from "mongoose";
import enquiryRoutes from "./routes/enquiry.js";
import adminRoutes from "./routes/adminRoutes.js";

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose
  .connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB Connected ✅"))
  .catch((err) => console.error("MongoDB connection error ❌", err));

// Routes
app.use("/api/admin", adminRoutes);
app.use("/api/enquiry", enquiryRoutes);

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
